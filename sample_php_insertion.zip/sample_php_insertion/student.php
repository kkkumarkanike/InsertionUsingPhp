<?php

//credentials

$host='localhost';
$user='root';        
$pwd='';

// connect to server

$con = mysqli_connect($host,$user,$pwd);

//connect to student database

mysqli_select_db($con, "student");

//inserting data into daabase

if(isset($_POST["insert"])){
    //data insertion
   $var = mysqli_query($con, "insert into student_details values('$_POST[id]','$_POST[name]','$_POST[class]','$_POST[division]')");
    if($var)
      {
    echo "data inseted successfully";
      }
    else
     {
    echo "data not inserted please check connections or data ";
    }
}



?>



